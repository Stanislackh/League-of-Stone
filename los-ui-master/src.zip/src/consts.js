const SERVER_URL = "http://localhost:3001";

export { SERVER_URL };
